from django import forms
from .models import Product, Shop

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['title', 'price', 'description', 'quantity', 'tags']

class shopForm(forms.ModelForm):
    class Meta:
        model = Shop
        fields = ['title', 'description', 'products']
