from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib import messages
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm 
from .models import Message, Product, Shop
from .forms import ProductForm, shopForm

# Create your views here.



def loginPage(request):
    if request.user.is_authenticated:
        return redirect('home')
    
 


    if request.method == 'POST':
        username = request.POST.get('username').lower()
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Username or password does not exist')
    return render(request, 'base/login_register.html', {'page': 'login'})


def registerPage(request):
    form = UserCreationForm(request.POST or None)
    if form.is_valid():
        user = form.save(commit=False)
        user.username = user.username.lower()
        user.save()
        login(request, user)
        return redirect('home')
    return render(request, 'base/login_register.html', {'form': form})


def logoutUser(request):
    logout(request)
    return redirect('home')


from django.shortcuts import render
from django.db.models import Q
from .models import Product, Shop

from django.shortcuts import render, get_object_or_404
from django.db.models import Q
from .models import Product, Shop

def home(request):
    query = request.GET.get('q', '')
    shop_id = request.GET.get('shop_id', '')
    
    # Filter products based on search query
    products = Product.objects.filter(Q(title__icontains=query) | Q(description__icontains=query))
    
    # Filter shop based on shop_id if provided
    shop = None
    if shop_id:
        shop = get_object_or_404(Shop, id=shop_id)

    context = {'products': products, 'shop': shop}
    return render(request, 'base/home.html', context)


def userProfile(request, pk):
    user = get_object_or_404(User, pk=pk)
    context = {'user': user}
    return render(request, 'base/user_profile.html', context)


def product_list(request):
    product = Product.objects.all()
    return render(request, 'base/products.html', {'product': product})


def product_details(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'base/product_details.html', {'product': product})


def sell_products(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)
            product.owner = request.user
            product.save()
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'base/sell_products.html', {'form': form})

@login_required(login_url='login')
def deleteMessage(request, pk):
    message = Message.objects.get(id=pk)

    if request.user != message.user:
        return HttpResponse('you are not allowed to delete this product')
    
    if request.method == 'POST':
        message.delete()
        return redirect('home')
    return render(request, 'base/delete.html', {'obj' : message})

@login_required(login_url='login')
def createProducts(request):
    form = ProductForm()
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid(): 
            Products = form.save(commit=False)
            Products.owner = request.user
            Products.save()
            return redirect('home')
        
    context = {'form' : form}
    return render(request, 'base/products_form.html', context)

@login_required(login_url='login')
def updateProducts(request, pk):
    product = get_object_or_404(Product, id=pk)
    form = ProductForm(instance=product)

    if request.user != product.owner:
        return HttpResponse('You are not allowed to update this product')

    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('home')

    context = {'form': form}
    return render(request, 'base/products_form.html', context)

@login_required(login_url='login')
def deleteProducts(request, pk):
    product = get_object_or_404(Product, id=pk)

    if request.user != product.owner:
        return HttpResponse('You are not allowed to delete this product')
    
    if request.method == 'POST':
        product.delete()
        return redirect('home')
    return render(request, 'base/delete.html', {'obj': product})

def Shop(request, shop_id):
    # Get the shop object
    shop = get_object_or_404(Shop, id=shop_id)
    
    # Check if the logged-in user is the owner of the shop
    if request.user != shop.owner:
        return redirect('home')  # Or any other page or action
    
    # Get products associated with the shop
    products = Product.objects.filter(shop_id=shop.id)

    # Pass shop and products to the template
    return render(request, 'shop.html', {'shop': shop, 'products': products})

def add_product_to_shop(request, shop_id):
    shop = get_object_or_404(Shop, id=shop_id)
    
    # Ensure that the logged-in user is the owner of the shop
    if request.user != shop.owner:
        return redirect('home')
    
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save(commit=False)
            product.owner = request.user
            product.save()
            shop.products.add(product)
            return redirect('shop_detail', shop_id=shop_id)
    else:
        form = ProductForm()
    
    return render(request, 'add_product_to_shop.html', {'form': form})

@login_required(login_url='login')
def createShop(request):
    form = shopForm()
    if request.method == 'POST':
        form = shopForm(request.POST)
        if form.is_valid(): 
            shop = form.save(commit=False)
            shop.owner = request.user
            shop.save()
            return redirect('home')
        
    context = {'form' : form}
    return render(request, 'base/shop_form.html', context)

from .models import Product  # Import the Product model

def shop_list(request):
    products = Product.objects.all()  # Fetch all Product objects
    return render(request, 'base/shop_list.html', {'products': products})  # Pass 'products' to the template

#def Statistics(request):
    #product = get_object_or_404(Product, id=pk)
    

